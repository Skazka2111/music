# Dubai — personalized property selection

An editable editorial-motion Reels, rebuilt from the supplied Remotion project.
**1080 × 1920 · 30 fps · original English narration, 28.467664 seconds.**

## Preview and export

Requires Node.js 20+, npm, and FFmpeg on PATH. All visual assets and fonts are local.

```sh
npm ci
npm start
# Open the Studio URL printed by Remotion; select DubaiPropertyGuide.
npm run typecheck
npm run render
```

Outputs:
- `out/dubai-property-reels.mp4`: H.264, yuv420p, 1080×1920, 30 fps; original narration encoded as AAC.
- `out/preview.mp4`: a smaller 540×960 review copy with identical timing.

The exporter uses system Chromium if `/usr/bin/chromium` is present; otherwise Remotion's supported browser. Set `REMOTION_BROWSER_EXECUTABLE` to select your own Chrome/Chromium. Initial installation/browser download may require Internet access; animation, lip-sync playback and final export do not call any paid API or service.

## Editable scenes

| Scene | Start | Source |
|---|---:|---|
| Hook / choose with clarity | 0.000 s | `src/Opening.tsx` |
| Options / districts and apartments | 5.100 s | `src/Options.tsx` |
| Expert selection / filtering | 11.167 s | `src/Expert.tsx` |
| Location / Budget / Preferences | 14.467 s | `src/Criteria.tsx` |
| Get Your Personalized Property List | 20.100 s | `src/Finale.tsx` |

`src/video.tsx` is the editable parent timeline. The same scene components are registered as separate Studio compositions in `src/root.tsx`. Each incoming scene uses a 16-frame upward reveal while the preceding scene remains underneath. Typography, colours, building illustrations and presenter rig are in `src/design.tsx`. Property drawings are original procedural SVG illustrations, rather than representations of actual listings. Captions are editable JSON in `public/assets/captions.json`.

## Character and speech

The original PNGs and WAV are preserved. Neutral is used for the opening and invitation; the pointing pose accompanies expert guidance. Only a localized SVG mouth interior changes while the original head, eyes, beard, hair and outer silhouette stay fixed. Eight continuous viseme targets are smoothed over 45 ms and driven by `public/assets/lip-sync.json`, generated locally using the free Rhubarb Lip Sync 1.14.0 English recognizer and the supplied dialogue. This is automatic phonetic lip-sync, not hand-animated articulation. Mouth positions for each pose can be adjusted in `Presenter` if changing artwork. An SVG alpha-edge filter reduces the source images' white matte fringe without changing the PNG files. No whole-image mouth swapping is used.

To regenerate lip cues after replacing the recording, download Rhubarb Lip Sync from its official GitHub releases and run:

```sh
rhubarb -f json -d public/assets/dialog.txt -o public/assets/lip-sync.json public/assets/narration.wav
```

Update the scene timing and composition duration when changing the recording. The current composition has **854 frames**, the nearest 30 fps frame boundary to the original voice (a difference of approximately **1 ms**). The export script muxes the entire original WAV without trimming, changing speed, or resynthesizing it. The MP4 container is approximately 28.468 seconds, determined by the original recording.

## Validation

- TypeScript type check.
- Studio server and composition preview.
- Review renders at scene entrances, transitions, and final CTA.
- Close-up comparison of speaking mouth states; head pixels outside the mouth stay identical once the entrance motion finishes.
- Full MP4 decode, video dimensions/frame rate, voice duration and A/V alignment checks.

The original unused poses, mouth patch, old envelope and original caption data remain available in `public/assets` for further editing. They are not used to swap the character's head during speech.

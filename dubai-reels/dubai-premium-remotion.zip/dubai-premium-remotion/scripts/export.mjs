import { existsSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { spawnSync } from "node:child_process";
const project = fileURLToPath(new URL("../", import.meta.url));
const run = (cmd, args) => {
  const p = spawnSync(cmd, args, { cwd: project, stdio: "inherit" });
  if (p.error) throw p.error;
  if (p.status !== 0) process.exit(p.status ?? 1);
};
mkdirSync(resolve(project, "out"), { recursive: true });
const browser =
  process.env.REMOTION_BROWSER_EXECUTABLE ||
  (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : null);
run(resolve(project, "node_modules/.bin/remotion"), [
  "render",
  "src/index.ts",
  "DubaiPropertyGuide",
  "out/dubai-picture.mp4",
  "--muted",
  "--codec=h264",
  "--crf=18",
  "--pixel-format=yuv420p",
  "--color-space=bt709",
  "--concurrency=3",
  ...(browser ? [`--browser-executable=${browser}`] : []),
]);
// Mux the whole original recording. No rate change, cut, or synthetic voice.
// 854 frames at 30 fps = 28.466667 s; original voice = 28.467664 s.
run("ffmpeg", [
  "-nostdin",
  "-y",
  "-v",
  "warning",
  "-i",
  "out/dubai-picture.mp4",
  "-i",
  "public/assets/narration.wav",
  "-map",
  "0:v:0",
  "-map",
  "1:a:0",
  "-c:v",
  "copy",
  "-c:a",
  "aac",
  "-b:a",
  "192k",
  "-movflags",
  "+faststart",
  "out/dubai-property-reels.mp4",
]);
run("ffmpeg", [
  "-nostdin",
  "-y",
  "-v",
  "warning",
  "-i",
  "out/dubai-property-reels.mp4",
  "-vf",
  "scale=540:960",
  "-c:v",
  "libx264",
  "-crf",
  "23",
  "-preset",
  "fast",
  "-c:a",
  "copy",
  "-movflags",
  "+faststart",
  "out/preview.mp4",
]);

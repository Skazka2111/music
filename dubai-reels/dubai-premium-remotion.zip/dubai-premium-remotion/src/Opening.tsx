import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import {
  Frame,
  Label,
  Reveal,
  Presenter,
  Tower,
  C,
  clamp,
  Arrow,
} from "./design";
export const Opening = () => {
  const f = useCurrentFrame();
  return (
    <Frame first>
      <Label index="01" />
      <div style={{ position: "absolute", left: 88, top: 285, right: 80 }}>
        <Reveal delay={-30}>
          <div
            style={{
              fontSize: 182,
              fontWeight: 600,
              lineHeight: 1,
              letterSpacing: -11,
            }}
          >
            DUBAI.
          </div>
        </Reveal>
        <Reveal delay={0}>
          <div
            style={{
              fontSize: 110,
              fontWeight: 500,
              lineHeight: 1.07,
              letterSpacing: -6,
            }}
          >
            Choose with
            <br />
            clarity.
          </div>
        </Reveal>
        <div
          style={{
            height: 5,
            width: interpolate(f, [20, 57], [0, 510], clamp),
            background: C.ink,
            marginTop: 37,
          }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: -160,
          top: 920,
          width: 860,
          height: 710,
          opacity: 0.22,
          translate: `${interpolate(f, [0, 153], [-40, 30], clamp)}px 0`,
        }}
      >
        <Tower variant={1} />
      </div>
      <div style={{ position: "absolute", left: 85, top: 890, width: 350 }}>
        <Reveal delay={34}>
          <div style={{ fontSize: 26, letterSpacing: 3, fontWeight: 600 }}>
            THE RIGHT HOME.
          </div>
        </Reveal>
        <Reveal delay={43}>
          <div
            style={{
              fontSize: 44,
              lineHeight: 1.18,
              letterSpacing: -1,
              marginTop: 20,
            }}
          >
            Without the
            <br />
            wrong turns.
          </div>
        </Reveal>
        <div
          style={{
            marginTop: 50,
            width: 86,
            height: 86,
            border: "1px solid " + C.line,
            borderRadius: "50%",
            display: "grid",
            placeItems: "center",
            rotate: "90deg",
          }}
        >
          <Arrow size={40} />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 450,
          top: 800,
          width: 490,
          height: 720,
          background: C.lime,
          borderRadius: "245px 245px 0 0",
          scale: interpolate(f, [8, 45], [0.9, 1], clamp),
        }}
      />
      <Presenter x={230} y={785} width={1030} offset={0} delay={-14} />
    </Frame>
  );
};

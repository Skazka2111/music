import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import {
  Frame,
  Label,
  Reveal,
  C,
  clamp,
  Arrow,
  Presenter,
  ArchitecturalCard,
} from "./design";
export const Finale = () => {
  const f = useCurrentFrame();
  return (
    <Frame dark>
      <Label index="05" dark />
      <div style={{ position: "absolute", left: 88, top: 288, right: 70 }}>
        <Reveal delay={8}>
          <div
            style={{
              fontSize: 95,
              lineHeight: 1.09,
              fontWeight: 500,
              letterSpacing: -4,
            }}
          >
            Get Your
            <br />
            <span style={{ color: C.lime }}>Personalized</span>
            <br />
            Property List.
          </div>
        </Reveal>
        <Reveal delay={27}>
          <div style={{ fontSize: 35, marginTop: 31, opacity: 0.68 }}>
            Your next chapter starts here.
          </div>
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: 105,
          top: 850,
          width: 405,
          height: 338,
          background: "#466069",
          rotate: "2deg",
          translate: `0 ${interpolate(f, [70, 135], [0, 24], clamp)}px`,
          opacity: interpolate(f, [65, 95], [0, 1], clamp),
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 97,
          top: 837,
          width: 405,
          height: 338,
          background: "#758985",
          rotate: "-1deg",
          translate: `0 ${interpolate(f, [70, 135], [0, 12], clamp)}px`,
          opacity: interpolate(f, [60, 90], [0, 1], clamp),
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 88,
          top: 824,
          rotate: "-4deg",
          scale: interpolate(f, [23, 60], [0.91, 1], clamp),
          opacity: interpolate(f, [23, 50], [0, 1], clamp),
        }}
      >
        <ArchitecturalCard
          name="Your Dubai shortlist"
          meta="CURATED AROUND YOU"
          selected
          variant={1}
          style={{ width: 405, color: C.ink }}
        />
        <div
          style={{
            fontSize: 23,
            marginTop: 32,
            letterSpacing: 1.5,
            color: C.lime,
          }}
        >
          SELECTED. NOT SCROLLED.
        </div>
      </div>
      <Presenter x={480} y={845} width={690} offset={603} delay={28} />
      <div
        style={{
          position: "absolute",
          left: 88,
          right: 88,
          top: 1360,
          height: 126,
          background: C.lime,
          color: C.ink,
          padding: "30px 38px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          translate: `0 ${interpolate(f, [37, 67], [55, 0], clamp)}px`,
          opacity: interpolate(f, [37, 58], [0, 1], clamp),
        }}
      >
        <span style={{ fontSize: 42, fontWeight: 600, letterSpacing: -1 }}>
          Get my personalized list
        </span>
        <div
          style={{
            translate: `${interpolate(f, [145, 200], [0, 10], clamp)}px 0`,
          }}
        >
          <Arrow size={49} />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 88,
          right: 88,
          top: 1520,
          display: "flex",
          alignItems: "center",
          gap: 18,
          fontSize: 24,
          color: "#AABAB8",
        }}
      >
        <span style={{ color: C.lime }}>01</span> Click below{" "}
        <span style={{ opacity: 0.3 }}> / </span>
        <span style={{ color: C.lime }}>02</span> Share your details
      </div>
    </Frame>
  );
};

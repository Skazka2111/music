import React from "react";
import {
  AbsoluteFill,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  Easing,
} from "remotion";
import cues from "../public/assets/lip-sync.json";
export const C = {
  ink: "#112B35",
  paper: "#F2F0E9",
  lime: "#D6F66B",
  muted: "#6D7979",
  line: "#C9CEBF",
  white: "#FBFAF5",
};
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const clamp = {
  extrapolateLeft: "clamp" as const,
  extrapolateRight: "clamp" as const,
  easing: ease,
};
export const FONT = "Editorial, Arial, sans-serif";
export const FontStyle = () => (
  <style>{`@font-face{font-family:Editorial;src:url('${staticFile("fonts/OpenAISans-Regular.woff2")}');font-weight:400}@font-face{font-family:Editorial;src:url('${staticFile("fonts/OpenAISans-Medium.woff2")}');font-weight:500}@font-face{font-family:Editorial;src:url('${staticFile("fonts/OpenAISans-Semibold.woff2")}');font-weight:600}@font-face{font-family:Editorial;src:url('${staticFile("fonts/OpenAISans-Bold.woff2")}');font-weight:700}*{box-sizing:border-box}`}</style>
);
export const Frame: React.FC<{
  children: React.ReactNode;
  dark?: boolean;
  lime?: boolean;
  first?: boolean;
}> = ({ children, dark, lime, first }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: lime ? C.lime : dark ? C.ink : C.paper,
        color: dark ? C.paper : C.ink,
        fontFamily: FONT,
        overflow: "hidden",
        clipPath: first
          ? "none"
          : `inset(${interpolate(f, [0, 16], [100, 0], clamp)}% 0 0 0)`,
      }}
    >
      <FontStyle />
      <div
        style={{
          position: "absolute",
          inset: 0,
          maskImage:
            "linear-gradient(to bottom, black 0px, black 1535px, transparent 1610px)",
          WebkitMaskImage:
            "linear-gradient(to bottom, black 0px, black 1535px, transparent 1610px)",
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};
export const Label: React.FC<{ dark?: boolean; index: string }> = ({
  dark,
  index,
}) => (
  <div
    style={{
      position: "absolute",
      top: 140,
      left: 88,
      right: 88,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      fontSize: 25,
      fontWeight: 600,
      letterSpacing: 3,
    }}
  >
    <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
      <svg width="37" height="37" viewBox="0 0 40 40">
        <path
          d="M6 31V9h13q15 0 15 11T19 31z"
          fill="none"
          stroke={dark ? C.lime : C.ink}
          strokeWidth="3"
        />
        <path d="M17 9v22" stroke={dark ? C.lime : C.ink} strokeWidth="3" />
      </svg>
      DUBAI / PROPERTY
    </div>
    <span style={{ fontSize: 22, opacity: 0.55 }}>{index} / 05</span>
  </div>
);
export const Reveal: React.FC<{
  children: React.ReactNode;
  delay?: number;
  style?: React.CSSProperties;
}> = ({ children, delay = 0, style }) => {
  const f = useCurrentFrame();
  return (
    <div style={{ overflow: "hidden", ...style }}>
      <div
        style={{
          translate: `0 ${interpolate(f, [delay, delay + 26], [115, 0], clamp)}%`,
          opacity: interpolate(f, [delay, delay + 15], [0, 1], clamp),
        }}
      >
        {children}
      </div>
    </div>
  );
};
export const Arrow = ({
  size = 60,
  color = C.ink,
}: {
  size?: number;
  color?: string;
}) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path d="M12 52L52 12M13 12h39v39" stroke={color} strokeWidth="4" />
  </svg>
);
export const Tower = ({
  variant = 0,
  color = C.ink,
}: {
  variant?: number;
  color?: string;
}) => (
  <svg
    viewBox="0 0 340 300"
    style={{ width: "100%", height: "100%" }}
    fill="none"
  >
    <g stroke={color} strokeWidth="1.5" opacity=".8">
      <path d="M12 274h316M45 270V96l94-36 46 22v188M139 60v210M45 96l94 24 46-38M139 120v150" />
      <path
        d={
          variant % 2
            ? "M179 270V49l67-23 46 30v214M246 26v244M179 49l67 29 46-22"
            : "M179 270V126l67-24 46 20v148M246 102v168M179 126l67 28 46-32"
        }
      />
      {Array.from({ length: 9 }, (_, i) => (
        <g key={i}>
          <path d={`M46 ${112 + i * 17}l93 24 45-36`} />
          <path d={`M180 ${140 + i * 13}l66 26 45-34`} />
        </g>
      ))}
      <path
        d="M18 287l150-5 147 5M81 86v184M109 74v196M213 115v155M271 114v156"
        opacity=".4"
      />
    </g>
  </svg>
);
// Only the mouth interior is animated. The supplied head, beard and silhouette never swap.
const shapes: Record<string, { h: number; w: number; teeth: number }> = {
  X: { h: 0, w: 1, teeth: 0 },
  A: { h: 1, w: 0.93, teeth: 0 },
  B: { h: 6, w: 1, teeth: 1 },
  C: { h: 13, w: 1, teeth: 1 },
  D: { h: 22, w: 0.95, teeth: 0.8 },
  E: { h: 14, w: 0.63, teeth: 0 },
  F: { h: 9, w: 0.5, teeth: 0 },
  G: { h: 3, w: 1, teeth: 0.9 },
  H: { h: 10, w: 1, teeth: 0.3 },
};
const sample = (t: number) => {
  const c = cues.mouthCues.find((c) => t >= c.start && t < c.end);
  if (!c) return shapes.X;
  const i = cues.mouthCues.indexOf(c);
  const prev = shapes[cues.mouthCues[Math.max(0, i - 1)].value] ?? shapes.X;
  const next = shapes[c.value] ?? shapes.X;
  const k = Math.min(1, Math.max(0, (t - c.start) / 0.045));
  return {
    h: prev.h + (next.h - prev.h) * k,
    w: prev.w + (next.w - prev.w) * k,
    teeth: prev.teeth + (next.teeth - prev.teeth) * k,
  };
};
export const Presenter: React.FC<{
  pose?: "neutral" | "point";
  x: number;
  y: number;
  width: number;
  offset: number;
  delay?: number;
}> = ({ pose = "neutral", x, y, width, offset, delay = 0 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = sample((f + offset) / fps);
  const cx = pose === "point" ? 623 : 606;
  const cy = pose === "point" ? 391 : 380;
  const w = 43 * s.w;
  const top = cy - 5;
  const h = s.h;
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width,
        height: (width * 1536) / 1220,
        translate: `0 ${interpolate(f, [delay, delay + 30], [85, 0], clamp)}px`,
        opacity: interpolate(f, [delay, delay + 16], [0, 1], clamp),
      }}
    >
      <svg width="0" height="0" style={{ position: "absolute" }}>
        <defs>
          <filter id={`edge-${pose}`} colorInterpolationFilters="sRGB">
            <feMorphology
              in="SourceAlpha"
              operator="erode"
              radius="0.75"
              result="clean"
            />
            <feComposite in="SourceGraphic" in2="clean" operator="in" />
          </filter>
        </defs>
      </svg>
      <Img
        src={staticFile(`assets/${pose}.png`)}
        style={{
          width: "100%",
          height: "100%",
          position: "absolute",
          filter: `url(#edge-${pose})`,
        }}
      />
      <svg
        viewBox="0 0 1220 1536"
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          overflow: "visible",
        }}
      >
        <g opacity={Math.min(1, h / 2)}>
          <path
            d={`M${cx - w} ${top}Q${cx} ${cy + 5} ${cx + w} ${top}Q${cx + w - 4} ${cy + 9 + h} ${cx} ${cy + 9 + h}Q${cx - w + 4} ${cy + 9 + h} ${cx - w} ${top}Z`}
            fill="#502B29"
          />
          <path
            d={`M${cx - w + 5} ${top + 2}Q${cx} ${cy + 5} ${cx + w - 5} ${top + 2}L${cx + w - 9} ${top + 7}Q${cx} ${cy + 9} ${cx - w + 9} ${top + 7}Z`}
            fill="#FFF1DC"
            opacity={s.teeth}
          />
          <ellipse
            cx={cx}
            cy={cy + 5 + h}
            rx={w * 0.52}
            ry={Math.max(0, h * 0.12)}
            fill="#BD786B"
            opacity={Math.min(1, h / 15)}
          />
        </g>
      </svg>
    </div>
  );
};
export const ArchitecturalCard: React.FC<{
  name: string;
  meta: string;
  variant?: number;
  dark?: boolean;
  selected?: boolean;
  style?: React.CSSProperties;
}> = ({ name, meta, variant = 0, dark, selected, style }) => (
  <div
    style={{
      width: 370,
      background: dark ? "#24404A" : C.white,
      border: `1px solid ${dark ? "#48606A" : C.line}`,
      borderRadius: 4,
      overflow: "hidden",
      ...style,
    }}
  >
    <div
      style={{
        height: 230,
        background: dark ? "#1B3640" : "#E5E7DC",
        padding: 14,
        position: "relative",
      }}
    >
      <Tower variant={variant} color={dark ? "#A4B9B8" : C.ink} />
      {selected && (
        <div
          style={{
            position: "absolute",
            right: 20,
            top: 20,
            width: 48,
            height: 48,
            borderRadius: "50%",
            background: C.lime,
            color: C.ink,
            display: "grid",
            placeItems: "center",
            fontSize: 30,
          }}
        >
          ✓
        </div>
      )}
    </div>
    <div style={{ padding: "24px 26px" }}>
      <div style={{ fontSize: 29, fontWeight: 600 }}>{name}</div>
      <div style={{ fontSize: 21, opacity: 0.6, marginTop: 10 }}>{meta}</div>
    </div>
  </div>
);

import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { Frame, Label, Reveal, Presenter, C, clamp, Arrow } from "./design";
export const Expert = () => {
  const f = useCurrentFrame();
  return (
    <Frame lime>
      <Label index="03" />
      <div style={{ position: "absolute", left: 88, top: 285 }}>
        <Reveal delay={8}>
          <div
            style={{
              fontSize: 126,
              lineHeight: 1.02,
              letterSpacing: -7,
              fontWeight: 500,
            }}
          >
            Less noise.
            <br />
            More you.
          </div>
        </Reveal>
        <Reveal delay={23}>
          <div style={{ fontSize: 40, marginTop: 36 }}>
            Let the experts narrow it down.
          </div>
        </Reveal>
      </div>
      <div style={{ position: "absolute", left: 88, top: 805, width: 430 }}>
        <div style={{ fontSize: 24, letterSpacing: 3, marginBottom: 33 }}>
          EXPERT SELECTION
        </div>
        {["Understand you", "Filter the market", "Find your fit"].map(
          (s, i) => (
            <div
              key={s}
              style={{
                display: "flex",
                gap: 22,
                alignItems: "center",
                padding: "28px 0",
                borderTop: "1px solid #112B3544",
                opacity: interpolate(
                  f,
                  [25 + i * 9, 42 + i * 9],
                  [0, 1],
                  clamp,
                ),
                translate: `${interpolate(f, [25 + i * 9, 49 + i * 9], [-40, 0], clamp)}px 0`,
              }}
            >
              <span style={{ fontSize: 23, opacity: 0.55 }}>0{i + 1}</span>
              <span style={{ fontSize: 34, letterSpacing: -0.5 }}>{s}</span>
            </div>
          ),
        )}
        <div
          style={{
            marginTop: 45,
            display: "flex",
            gap: 11,
            height: 76,
            alignItems: "flex-end",
          }}
        >
          {Array.from({ length: 9 }, (_, i) => (
            <div
              key={i}
              style={{
                width: 24,
                height: interpolate(
                  f,
                  [40 + i * 2, 74 + i],
                  [64 - (i % 3) * 12, i < 3 ? 50 + i * 10 : 8],
                  clamp,
                ),
                background: C.ink,
                opacity: interpolate(
                  f,
                  [40 + i * 2, 74 + i],
                  [0.18, i < 3 ? 1 : 0.12],
                  clamp,
                ),
              }}
            />
          ))}
        </div>
        <div
          style={{
            marginTop: 30,
            fontSize: 22,
            letterSpacing: 2,
            opacity: interpolate(f, [58, 77], [0, 1], clamp),
          }}
        >
          OPTIONS → YOUR MATCHES
        </div>
      </div>
      <Presenter
        pose="point"
        x={352}
        y={775}
        width={880}
        offset={335}
        delay={18}
      />
    </Frame>
  );
};

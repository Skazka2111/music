import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
} from "remotion";
import captions from "../public/assets/captions.json";
import type { Caption } from "@remotion/captions";
const captionData: Caption[] = captions;
import { Opening } from "./Opening";
import { Options } from "./Options";
import { Expert } from "./Expert";
import { Criteria } from "./Criteria";
import { Finale } from "./Finale";
import { C, FONT, FontStyle } from "./design";
export const DubaiGuide = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const caption = captionData.find(
    (c) => t * 1000 >= c.startMs && t * 1000 < c.endMs,
  );
  const dark = (t >= 5.1 && t < 11.167) || t >= 20.1;
  return (
    <AbsoluteFill style={{ background: C.paper }}>
      <FontStyle />
      <Audio src={staticFile("assets/narration.wav")} />
      <Sequence
        name="01 — Choose with clarity"
        from={0}
        durationInFrames={169}
        premountFor={fps}
      >
        <Opening />
      </Sequence>
      <Sequence
        name="02 — An overwhelming market"
        from={153}
        durationInFrames={198}
        premountFor={fps}
      >
        <Options />
      </Sequence>
      <Sequence
        name="03 — Expert filtering"
        from={335}
        durationInFrames={115}
        premountFor={fps}
      >
        <Expert />
      </Sequence>
      <Sequence
        name="04 — Personal criteria"
        from={434}
        durationInFrames={185}
        premountFor={fps}
      >
        <Criteria />
      </Sequence>
      <Sequence
        name="05 — Personalized list"
        from={603}
        durationInFrames={251}
        premountFor={fps}
      >
        <Finale />
      </Sequence>
      {caption && (
        <div
          style={{
            position: "absolute",
            left: 88,
            right: 88,
            top: 1668,
            minHeight: 110,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: FONT,
            fontSize: 35,
            lineHeight: 1.32,
            letterSpacing: -0.4,
            textAlign: "center",
            fontWeight: 400,
            color: dark ? C.paper : C.ink,
            opacity: interpolate(
              t,
              [caption.startMs / 1000, caption.startMs / 1000 + 0.1],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
            ),
          }}
        >
          {caption.text}
        </div>
      )}
      <div
        style={{
          position: "absolute",
          left: 88,
          right: 88,
          top: 1820,
          height: 2,
          background: dark ? "#496068" : "#C9CEBF",
        }}
      >
        <div
          style={{
            width: `${Math.min(100, (f / 853) * 100)}%`,
            height: 2,
            background: dark ? C.lime : C.ink,
          }}
        />
      </div>
    </AbsoluteFill>
  );
};

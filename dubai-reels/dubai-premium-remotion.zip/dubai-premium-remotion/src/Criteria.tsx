import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { Frame, Label, Reveal, C, clamp, Tower } from "./design";
const Item: React.FC<{
  label: string;
  sub: string;
  index: number;
  icon: string;
}> = ({ label, sub, index, icon }) => {
  const f = useCurrentFrame();
  const d = 23 + index * 17;
  return (
    <div
      style={{
        position: "absolute",
        left: 88,
        right: 88,
        top: 690 + index * 245,
        height: 215,
        borderBottom: "1px solid " + C.line,
        display: "flex",
        alignItems: "center",
        gap: 32,
        translate: `0 ${interpolate(f, [d, d + 30], [65, 0], clamp)}px`,
        opacity: interpolate(f, [d, d + 20], [0, 1], clamp),
      }}
    >
      <div
        style={{
          width: 124,
          height: 124,
          background: index === 1 ? C.lime : "#E5E7DC",
          borderRadius: 62,
          display: "grid",
          placeItems: "center",
        }}
      >
        <svg
          width="62"
          height="62"
          viewBox="0 0 64 64"
          fill="none"
          stroke={C.ink}
          strokeWidth="2.2"
        >
          {icon === "pin" ? (
            <>
              <path d="M32 56s18-17 18-32a18 18 0 0 0-36 0c0 15 18 32 18 32Z" />
              <circle cx="32" cy="24" r="6" />
            </>
          ) : icon === "budget" ? (
            <>
              <rect x="8" y="17" width="48" height="34" rx="6" />
              <path d="M10 17V9h39v8M41 30h15v12H41Z" />
              <circle cx="47" cy="36" r="1" />
            </>
          ) : (
            <>
              <path d="M9 14h46M9 32h46M9 50h46" />
              <circle cx="24" cy="14" r="5" fill={C.paper} />
              <circle cx="43" cy="32" r="5" fill={C.paper} />
              <circle cx="21" cy="50" r="5" fill={C.paper} />
            </>
          )}
        </svg>
      </div>
      <div>
        <div style={{ fontSize: 64, fontWeight: 500, letterSpacing: -2 }}>
          {label}
        </div>
        <div style={{ fontSize: 30, color: C.muted, marginTop: 10 }}>{sub}</div>
      </div>
      <div
        style={{
          marginLeft: "auto",
          width: 49,
          height: 49,
          border: "1px solid " + C.line,
          borderRadius: "50%",
          display: "grid",
          placeItems: "center",
          fontSize: 25,
          color: C.ink,
          background: f > d + 28 ? C.lime : "transparent",
        }}
      >
        ✓
      </div>
    </div>
  );
};
export const Criteria = () => (
  <Frame>
    <Label index="04" />
    <div style={{ position: "absolute", left: 88, top: 285 }}>
      <Reveal delay={8}>
        <div
          style={{
            fontSize: 110,
            lineHeight: 1.06,
            letterSpacing: -5,
            fontWeight: 500,
          }}
        >
          Your life.
          <br />
          Your shortlist.
        </div>
      </Reveal>
      <Reveal delay={23}>
        <div style={{ fontSize: 38, marginTop: 32, color: C.muted }}>
          Built around what matters to you.
        </div>
      </Reveal>
    </div>
    <Item
      label="Location"
      sub="The neighbourhood that fits."
      index={0}
      icon="pin"
    />
    <Item
      label="Budget"
      sub="A clear, comfortable range."
      index={1}
      icon="budget"
    />
    <Item
      label="Preferences"
      sub="Your priorities. Your lifestyle."
      index={2}
      icon="sliders"
    />
    <div
      style={{
        position: "absolute",
        left: 88,
        top: 1510,
        fontSize: 26,
        letterSpacing: 2,
      }}
    >
      PERSONAL CRITERIA → PERSONAL RESULTS
    </div>
  </Frame>
);

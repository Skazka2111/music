import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { Frame, Label, Reveal, ArchitecturalCard, C, clamp } from "./design";
const names = [
  "Downtown",
  "Dubai Marina",
  "Business Bay",
  "Palm Jumeirah",
  "Dubai Hills",
  "JVC",
];
export const Options = () => {
  const f = useCurrentFrame();
  return (
    <Frame dark>
      <Label index="02" dark />
      <div style={{ position: "absolute", left: 88, top: 285 }}>
        <Reveal delay={8}>
          <div
            style={{
              fontSize: 116,
              lineHeight: 1.03,
              letterSpacing: -6,
              fontWeight: 500,
            }}
          >
            So many
            <br />
            <span style={{ color: C.lime }}>possibilities.</span>
          </div>
        </Reveal>
        <Reveal delay={24}>
          <div style={{ fontSize: 38, opacity: 0.66, marginTop: 35 }}>
            Districts. Buildings. Apartments.
          </div>
        </Reveal>
      </div>
      <div
        style={{
          position: "absolute",
          left: -74,
          top: 740,
          width: 1260,
          height: 880,
          rotate: "-8deg",
          translate: `${interpolate(f, [15, 182], [120, -115], clamp)}px ${interpolate(f, [15, 182], [90, -90], clamp)}px`,
        }}
      >
        {names.map((n, i) => (
          <ArchitecturalCard
            key={n}
            dark
            name={n}
            meta={
              i % 2 ? "WATERFRONT / RESIDENTIAL" : "CITY LIVING / RESIDENTIAL"
            }
            variant={i}
            style={{
              position: "absolute",
              left: (i % 3) * 410,
              top: Math.floor(i / 3) * 420,
              opacity: interpolate(
                f,
                [20 + i * 7, 43 + i * 7],
                [0, 0.95],
                clamp,
              ),
              translate: `0 ${interpolate(f, [20 + i * 7, 55 + i * 7], [160, 0], clamp)}px`,
            }}
          />
        ))}
      </div>
      <div
        style={{
          position: "absolute",
          left: 88,
          right: 88,
          top: 1500,
          background: C.ink,
          paddingTop: 25,
          borderTop: "1px solid #52666B",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ fontSize: 28, letterSpacing: 2, color: C.lime }}>
          MORE OPTIONS ≠ BETTER FIT
        </div>
        <span style={{ fontSize: 47, fontWeight: 400 }}>?</span>
      </div>
    </Frame>
  );
};

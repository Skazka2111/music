import React from "react";
import { Composition, Folder } from "remotion";
import { DubaiGuide } from "./video";
import { Opening } from "./Opening";
import { Options } from "./Options";
import { Expert } from "./Expert";
import { Criteria } from "./Criteria";
import { Finale } from "./Finale";
export const Root: React.FC = () => (
  <>
    <Composition
      id="DubaiPropertyGuide"
      component={DubaiGuide}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={854}
    />
    <Folder name="Scenes">
      <Composition
        id="Opening"
        component={Opening}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={153}
      />
      <Composition
        id="Options"
        component={Options}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={182}
      />
      <Composition
        id="Expert"
        component={Expert}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={99}
      />
      <Composition
        id="Criteria"
        component={Criteria}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={169}
      />
      <Composition
        id="Finale"
        component={Finale}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={251}
      />
    </Folder>
  </>
);
